# CellSociety

### Robert Steilberg, Aaron Chang, Sam Curtis

####Overview

CellSociety is a cellular automata simulation engine coded in Java using the JavaFX framework. I developed this application with two other team members. I primarily served as the project's front end developer, overseeing GUI development, CSS styling, and simulation control. I was additionally in charge of interfacing the front end GUI with the program's back end logic that powers each simulation.

The application simulates several different cellular automata simulations along with GUI controls that allow the user to customize how each simulation is executed. The software stack also includes a DOM parser for XML; this allowed for further modifications of simulation parameters through XML files tailored for each type of simulation.

#####Instructions
The simulation initializes with the default simulation defined in the English.properties properties file. The user can change the simulation with the combo box containing each type of simulation. Upon choosing a simulation, the user is prompted to choose a corresponding XML file to initialize the parameters for that simulation. The "Play" button plays the simulation, the "Pause" button pauses it, the "Step" button steps through it, the "Stop & Reset" button resets the simulations to the initial parameters, and the "Change XML File" allows the user to change the initial parameters for the simulation type. The slider can be used to control the speed at which the simulation steps through each frame. The graph displays information about the number of cells of each state in every time frame of the simulation.
